#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Sep  4 15:44:45 2018

@author: liximing
"""

a=2
print a